function inchesscount()
global hesscount
hesscount = hesscount + 1;