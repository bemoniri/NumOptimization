function incgradcount()
global gradcount
gradcount = gradcount + 1;