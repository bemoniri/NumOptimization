function incfuncount()
global funccount
funccount = funccount + 1;